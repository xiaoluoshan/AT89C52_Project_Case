#include <REGX52.H>
#include "intrins.h"

typedef unsigned int u16;
typedef unsigned char u8;

sbit KEY1=P3^1;
sbit KEY2=P3^0;
sbit KEY3=P3^2;
sbit KEY4=P3^3;


sbit BEEP=P2^5;

#define KEY1_PRESS  1
#define KEY2_PRESS  2
#define KEY3_PRESS  3
#define KEY4_PRESS  4
#define KEY_UNPRESS 0
#define LED_PORT	P2


void delay_10us(u16 ten_us)
{
    while(ten_us--);  
}
void delay_ms(u16 ten_ms)
{	
	while(ten_ms--)
	{
		delay_10us(100);
	}
	
}
void led_mode(u8 mode)
{
    u8 led_state=0x01;
		u8 i=0;
	
    for (;i<8;i++) 
		{
        LED_PORT=~led_state;
        led_state<<=1;
        delay_ms(1000);
    }
    for (i=0;i<8;i++) 
		{
        LED_PORT=~led_state;
        led_state>>=1;
        delay_ms(1000);
    }
}

void beep_alarm(u16 time,u16 fre)
{
	  u16 i=0;
	
    for(;i<time;i++)
    {
        BEEP=!BEEP;
        delay_10us(fre);
    }
}

u8 key_scan(void)
{
    static u8 key=0;

    if((KEY1==0||KEY2==0||KEY3==0||KEY4==0))
    {
        delay_10us(1000);

        if(KEY1==0)
        {
            key = 1;
            while(KEY1==0);
        }
        else if(KEY2==0)
        {
            key = 2;
            while(KEY2==0);
        }
        else if(KEY3==0)
        {
            key = 3;
            while(KEY3==0);
        }
        else if(KEY4==0)
        {
            key = 4;
            while(KEY4==0);
        }
    }
    else if(KEY1==1&&KEY2==1&&KEY3==1&&KEY4==1)
    {
        key=0;  
    }
    return key;       
}

void main()
{   
    u8 key_mode=0;

    while(1)
    {
        key_mode=key_scan();
			
        if (key_mode==1)
        {
            beep_alarm(1000,100);
        }
        else if(key_mode==2)
        {
            led_mode(2);
            delay_ms(5000);
        }
        else if(key_mode==3)
        {
            led_mode(3);
            delay_ms(5000);
        }
        else if(key_mode==4)
        {
            led_mode(4);
        }
        else
        {
            
        }       
    }       
}